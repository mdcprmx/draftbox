# Прежде чем смотреть задание прошу оценочку поставить по максимому. Если вы её поставите по максимуму то сделаете мир на чуточку лучше так как в мире станет на одного счастливого человека больше всем зарание спасибо и хорошего дня и настроения!!!!

# Сети в Linux

### 1.1. Сети и маски

## Part 1. Инструмент ipcalc

1) Адрес сети 192.167.38.54/13

<img src="images/Part 1.1.png" alt="ipcalc" width="500"/>

2) Перевод маски 255.255.255.0 в префиксную и двоичную запись, /15 в обычную и двоичную, 11111111.11111111.11111111.11110000 в обычную и префиксную

<img src="images/Part 1.1.2.0.png" alt="ipcalc netmask" width="500"/>
<img src="images/Part 1.1.2.1.png" alt="ipcalc netmask" width="500"/>
<img src="images/Part 1.1.2.2.png" alt="ipcalc netmask" width="500"/>

3) Минимальный и максимальный хост в сети 12.167.38.4 при масках: /8, 11111111.11111111.00000000.00000000, 255.255.254.0 и /4

<img src="images/Part 1.1.3.1.png" alt="ipcalc minmaxhost" width="500"/>

<img src="images/Part 1.1.3.2.png" alt="ipcalc minmaxhost" width="500"/>

<img src="images/Part 1.1.3.3.png" alt="ipcalc minmaxhost" width="500"/>

<img src="images/Part 1.1.3.4.png" alt="ipcalc minmaxhost" width="500"/>

### 1.2. localhost

Определи и запиши в отчёт, можно ли обратиться к приложению, работающему на localhost, со следующими IP:

1) 194.34.23.100 - нет из-за отсутствия loopback
2) 127.0.0.2 - да, loopback имеется
3) 127.1.0.1 - да, loopback имеется
4) 128.0.0.1 - нет из-за отсутствия loopback

### 1.3. Диапазоны и сегменты сетей

1) Какие из перечисленных IP можно использовать в качестве публичного, а какие только в качестве частных: 
- 10.0.0.45 - Частный
- 134.43.0.2 - Публичный
- 192.168.4.2 - Частный
- 172.20.250.4 - Частный
- 172.0.2.1 - Публичный
- 192.172.0.1 - Частный
- 172.68.0.2 - Публичный
- 172.16.255.255 - Частный
- 10.10.10.10 - Частный
- 192.169.168.1 - Публичный

2)  Какие из перечисленных IP адресов шлюза возможны у сети 10.10.0.0/18: 
- 10.0.0.1 - нет
- 10.10.0.2 - да
- 10.10.10.10 - да
- 10.10.100.1 - нет
- 10.10.1.255 - да

## Part 2. Статическая маршрутизация между двумя машинами

<img src="images/Part 2.0.1.png" alt="ws-1 ip a" width="500"/>
<img src="images/Part 2.0.2.png" alt="ws-2 ip a" width="500"/>

<img src="images/Part 2.0.3.png" alt="ws-1 netplan fix" width="500"/>
<img src="images/Part 2.0.4.png" alt="ws-2 netplan fix" width="500"/>

<img src="images/Part 2.0.5.png" alt="ws-1 ip a fix" width="500"/>
<img src="images/Part 2.0.6.png" alt="ws-2 ip a fix" width="500"/>

### 2.1. Добавление статического маршрута вручную

<img src="images/Part 2.1.1.png" alt="ws-1" width="500"/>
<img src="images/Part 2.1.2.png" alt="ws-2" width="500"/>

<img src="images/Part 2.1.3.png" alt="ws-1 ping" width="500"/>
<img src="images/Part 2.1.4.png" alt="ws-2 ping" width="500"/>

### 2.2. Добавление статического маршрута с сохранением

<img src="images/Part 2.2.1.png" alt="ws-1" width="500"/>
<img src="images/Part 2.2.2.png" alt="ws-2" width="500"/>

<img src="images/Part 2.2.3.png" alt="ws-1 ping" width="500"/>
<img src="images/Part 2.2.4.png" alt="ws-2 ping" width="500"/>

## Part 3. Утилита iperf3

### 3.1. Скорость соединения

Переведи и запиши в отчёт: 8 Mbps в MB/s, 100 MB/s в Kbps, 1 Gbps в Mbps.

1) 8 Mbps = 1 MS/s
2) 100 MB.s = 100000 Kbps
3) 1 Gbps = 1000 Mbps

### 3.2. Утилита iperf3
- Скорость соединения между ws1 и ws2
<img src="images/Part 3.2.1.png" alt="ws-1 server" width="500"/>
<img src="images/Part 3.2.2.png" alt="ws-2 client" width="500"/>

## Part 4. Сетевой экран

### 4.1. Утилита iptables
- Создан файл /etc/firewall.sh, имитирующий фаерволл, на ws1 и ws2:
1) На ws1 примени стратегию, когда в начале пишется запрещающее правило, а в конце пишется разрешающее правило (это касается пунктов 4 и 5).

2) На ws2 примени стратегию, когда в начале пишется разрешающее правило, а в конце пишется запрещающее правило (это касается пунктов 4 и 5).

3) Открой на машинах доступ для порта 22 (ssh) и порта 80 (http).

4) Запрети echo reply (машина не должна «пинговаться», т.е. должна быть блокировка на OUTPUT).

5) Разреши echo reply (машина должна «пинговаться»).

<img src="images/Part 4.1.1.png" alt="ws-1 iptables" width="500"/>
<img src="images/Part 4.1.2.png" alt="ws-2 iptables" width="500"/>

<img src="images/Part 4.1.3.png" alt="ws-1 iptables" width="500"/>
<img src="images/Part 4.1.4.png" alt="ws-2 iptables" width="500"/>

- ws1 сначала разрешает вывод ping, потом запрещаем вывод ping
- ws2 сначала запрещаем вывод ping, потом разрешаем вывод ping

### 4.2. Утилита nmap

- Командой ping не пингуется машина 192.168.100.10
- Утилита nmap показаал, что хост машины запущен.

<img src="images/Part 4.2.1.png" alt="nmap" width="500"/>

## Part 5. Статическая маршрутизация сети

### 5.1. Настройка адресов машин

<img src="images/Part 5.1.1.png" alt="r1" width="500"/>
<img src="images/Part 5.1.2.png" alt="r2" width="500"/>
<img src="images/Part 5.1.3.png" alt="ws11" width="500"/>
<img src="images/Part 5.1.4.png" alt="ws21" width="500"/>
<img src="images/Part 5.1.5.png" alt="ws22" width="500"/>

- Перезапустить сервис сети. 
- Если ошибок нет, то командой ip -4 a проверить, что адрес машины задан верно. 
- Также пропинговать другие машины.

<img src="images/Part 5.1.6.png" alt="r1 ip -4 a" width="500"/>
<img src="images/Part 5.1.7.png" alt="r1 ping" width="500"/>

<img src="images/Part 5.1.8.png" alt="r2 ip -4 a" width="500"/>
<img src="images/Part 5.1.9.png" alt="r2 ping" width="500"/>
<img src="images/Part 5.1.10.png" alt="r2 ping" width="500"/>
<img src="images/Part 5.1.11.png" alt="r2 ping" width="500"/>

<img src="images/Part 5.1.12.png" alt="ws11 ip -4 a" width="500"/>
<img src="images/Part 5.1.13.png" alt="ws11 ping" width="500"/>
<img src="images/Part 5.1.14.png" alt="ws11 ping" width="500"/>

<img src="images/Part 5.1.15.png" alt="ws21 ip -4 a" width="500"/>
<img src="images/Part 5.1.16.png" alt="ws21 ping" width="500"/>

<img src="images/Part 5.1.17.png" alt="ws22 ip -4 a" width="500"/>
<img src="images/Part 5.1.18.png" alt="ws22 ping" width="500"/>
<img src="images/Part 5.1.19.png" alt="ws11 ping" width="500"/>

### 5.5. Построение списка маршрутизаторов

<img src="images/Part 5.5.1.png" width="500"/>
<img src="images/Part 5.5.2.png" width="500"/>

- Путь строиться от узла к узлу до того момента, покаа не будет достигнута конечная точка. Каждый пакет проходит на своем пути определенное количество узлов, пока достигнет своей цели. На каждом узле добавляется счетчик, который отслеживает количество пройденых узлов.

### 5.6. Использование протокола ICMP при маршрутизации

<img src="images/Part 5.6.1.png" width="500"/>
<img src="images/Part 5.6.2.png" width="500"/>

## Part 6. Динамическая настройка IP с помощью DHCP

<img src="images/Part 6.1.png" width="500"/>
<img src="images/Part 6.2.png" width="500"/>
<img src="images/Part 6.3.png" width="500"/>
<img src="images/Part 6.4.png" width="500"/>
<img src="images/Part 6.5.png" width="500"/>
<img src="images/Part 6.6.png" width="500"/>
<img src="images/Part 6.7.png" width="500"/>
<img src="images/Part 6.8.png" width="500"/>
<img src="images/Part 6.9.png" width="500"/>
<img src="images/Part 6.7.png" width="500"/>
<img src="images/Part 6.8.png" width="500"/>
<img src="images/Part 6.9.png" width="500"/>

## Part 7. NAT

- В файле /etc/apache2/ports.conf на ws22 и r1 изменили строку Listen 80 на Listen 0.0.0.0:80, то есть сделали сервер Apache2 общедоступным
<img src="images/Part 7.1.png" width="500"/>
<img src="images/Part 7.2.png" width="500"/>

- Пинг с ws22 до r1 не удаётся
<img src="images/Part 7.3.png" width="500"/>

- Успешно пропинговались с ws22 до r1 после разрешения маршрутизации icmp на r2
<img src="images/Part 7.4.png" width="500"/>

- Изменённый firewall.sh на r2
<img src="images/Part 7.5.png" width="500"/>

- Подключились с ws22 к серверу Apache на r1
<img src="images/Part 7.6.png" width="500"/>

- Подключились с r1 к серверу Apache на ws22
<img src="images/Part 7.7.png" width="500"/>

1) Удаление правил в таблице filter - iptables -F;

2) Удаление правил в таблице "NAT" - iptables -F -t nat;

3) Отбрасывать все маршрутизируемые пакеты - iptables --policy FORWARD DROP.